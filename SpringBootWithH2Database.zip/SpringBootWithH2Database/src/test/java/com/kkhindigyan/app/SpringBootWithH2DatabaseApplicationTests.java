package com.kkhindigyan.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithH2DatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
