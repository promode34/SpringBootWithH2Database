package com.reward.app.service;

import org.springframework.stereotype.Service;

import com.reward.app.entities.Rewards;

@Service
public interface RewardsService {
	public Rewards getRewardsByCustomerId(Long customerId);
}
