package com.reward.app.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.reward.app.entities.Customer;

@Repository
@Transactional
public interface CustomerRepository extends CrudRepository<Customer, Integer> {
	public Customer findByCustomerId(Long customerId);
}