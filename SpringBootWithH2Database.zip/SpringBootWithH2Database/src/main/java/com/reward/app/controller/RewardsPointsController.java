package com.reward.app.controller;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reward.app.dao.CustomerRepository;
import com.reward.app.entities.Customer;
import com.reward.app.entities.Rewards;
import com.reward.app.exception.CustomerNotFoundExcpetion;
import com.reward.app.service.RewardsService;

@RestController
@RequestMapping("/customers")
public class RewardsPointsController {

	@Autowired
	RewardsService rewardsService;

	@Autowired
	CustomerRepository customerRepository;

	@GetMapping(value = "/rewards/{customerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Rewards> getRewardsForCustomer(@PathVariable("customerId") Long customerId) {
		Customer customer = customerRepository.findByCustomerId(customerId);
		if (Objects.isNull(customer)) {
			throw new CustomerNotFoundExcpetion("Customer Id : " + customerId + " is not present in system ");
		}
		Rewards customerRewards = rewardsService.getRewardsByCustomerId(customerId);
		return new ResponseEntity<>(customerRewards, HttpStatus.OK);
	}

}