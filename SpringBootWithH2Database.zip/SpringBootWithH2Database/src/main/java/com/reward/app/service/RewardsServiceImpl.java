package com.reward.app.service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reward.app.constant.RewardPointsConstants;
import com.reward.app.dao.TransactionRepository;
import com.reward.app.entities.Rewards;
import com.reward.app.entities.Transaction;

@Service
public class RewardsServiceImpl implements RewardsService {

	@Autowired
	TransactionRepository transactionRepository;

	public Rewards getRewardsByCustomerId(Long customerId) {

		Timestamp firstMonthTimestamp = getDateBasedOnOffSetDays(RewardPointsConstants.MONTH.getValue());
		Timestamp secondMonthTimestamp = getDateBasedOnOffSetDays(2 * RewardPointsConstants.MONTH.getValue());
		Timestamp thirdMonthTimestamp = getDateBasedOnOffSetDays(3 * RewardPointsConstants.MONTH.getValue());

		List<Transaction> firstMonthTransactions = transactionRepository.findAllByCustomerIdAndTransactionDateBetween(
				customerId, firstMonthTimestamp, Timestamp.from(Instant.now()));
		List<Transaction> secondMonthTransactions = transactionRepository
				.findAllByCustomerIdAndTransactionDateBetween(customerId, secondMonthTimestamp, firstMonthTimestamp);
		List<Transaction> thirdMonthTransactions = transactionRepository
				.findAllByCustomerIdAndTransactionDateBetween(customerId, thirdMonthTimestamp, secondMonthTimestamp);

		Double firstMonthRewardPoints = getRewardsPerMonth(firstMonthTransactions);
		Double secondMonthRewardPoints = getRewardsPerMonth(secondMonthTransactions);
		Double thirdMonthRewardPoints = getRewardsPerMonth(thirdMonthTransactions);

		Rewards customerRewardPoints = new Rewards();
		customerRewardPoints.setCutsomerId(customerId);
		customerRewardPoints.setFirstMonthPoints(firstMonthRewardPoints);
		customerRewardPoints.setSecondMonthPoints(secondMonthRewardPoints);
		customerRewardPoints.setThirdMonthPoints(thirdMonthRewardPoints);
		customerRewardPoints.setTotalPoints(firstMonthRewardPoints + secondMonthRewardPoints + thirdMonthRewardPoints);

		return customerRewardPoints;

	}

	private Double getRewardsPerMonth(List<Transaction> transactions) {

		return transactions.stream().map(this::calculateRewards).collect(Collectors.summingDouble(Double::doubleValue));
	}

	private Double calculateRewards(Transaction t) {

		if (t.getTransactionAmount() > RewardPointsConstants.REWARDONE.getValue()
				&& t.getTransactionAmount() <= RewardPointsConstants.REWARDTWO.getValue()) {
			return (double) (t.getTransactionAmount() - RewardPointsConstants.REWARDONE.getValue());

		} else if (t.getTransactionAmount() > RewardPointsConstants.REWARDTWO.getValue()) {
			return (double) ((t.getTransactionAmount() - RewardPointsConstants.REWARDTWO.getValue()) * 2
					+ (RewardPointsConstants.REWARDTWO.getValue() - RewardPointsConstants.REWARDONE.getValue()));

		} else
			return (double) 0l;

	}

	public Timestamp getDateBasedOnOffSetDays(int days) {
		return Timestamp.valueOf(LocalDateTime.now().minusDays(days));
	}

}
