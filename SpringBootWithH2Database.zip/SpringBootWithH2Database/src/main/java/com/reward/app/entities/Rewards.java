package com.reward.app.entities;

public class Rewards {

	private double secondMonthPoints;
	private double thirdMonthPoints;
	private double totalPoints;
	private long cutsomerId;
	private double firstMonthPoints;

	public double getFirstMonthPoints() {
		return firstMonthPoints;
	}

	public void setFirstMonthPoints(double firstMonthPoints) {
		this.firstMonthPoints = firstMonthPoints;
	}

	public double getSecondMonthPoints() {
		return secondMonthPoints;
	}

	public void setSecondMonthPoints(double secondMonthPoints) {
		this.secondMonthPoints = secondMonthPoints;
	}

	public double getThirdMonthPoints() {
		return thirdMonthPoints;
	}

	public void setThirdMonthPoints(double thirdMonthPoints) {
		this.thirdMonthPoints = thirdMonthPoints;
	}

	public double getTotalPoints() {
		return totalPoints;
	}

	public void setTotalPoints(double totalPoints) {
		this.totalPoints = totalPoints;
	}

	public long getCutsomerId() {
		return cutsomerId;
	}

	public void setCutsomerId(long cutsomerId) {
		this.cutsomerId = cutsomerId;
	}

}