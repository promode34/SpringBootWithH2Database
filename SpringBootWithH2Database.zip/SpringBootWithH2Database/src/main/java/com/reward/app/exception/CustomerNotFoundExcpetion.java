package com.reward.app.exception;

public class CustomerNotFoundExcpetion extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CustomerNotFoundExcpetion(String errorMessage) {
		super(errorMessage);
	}

}
