package com.reward.app.constant;

public enum RewardPointsConstants {

	MONTH(30), REWARDONE(50), REWARDTWO(100);

	private int value;

	public int getValue() {
		return this.value;
	}

	RewardPointsConstants(int value) {
		this.value = value;
	}

}
